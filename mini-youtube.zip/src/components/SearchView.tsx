import React, { useState, useMemo } from 'react';
import { Search, X, SlidersHorizontal, ArrowLeft, Frown, Film } from 'lucide-react';
import { Video } from '../types';
import { VideoCard } from './VideoCard';
import { CREATOR_PROFILE } from '../utils/storage';

interface SearchViewProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  videos: Video[];
  onSelectVideo: (video: Video) => void;
  onBackToHome: () => void;
}

export const SearchView: React.FC<SearchViewProps> = ({
  searchQuery,
  setSearchQuery,
  videos,
  onSelectVideo,
  onBackToHome,
}) => {
  const [sortBy, setSortBy] = useState<'relevance' | 'newest' | 'views' | 'likes'>('relevance');

  // Filter videos by title (case-insensitive) as specified in requirement 4
  const filteredVideos = useMemo(() => {
    if (!searchQuery.trim()) return videos;
    const query = searchQuery.toLowerCase().trim();

    return videos.filter((v) => {
      const matchTitle = v.title.toLowerCase().includes(query);
      const matchDesc = v.description.toLowerCase().includes(query);
      const matchCategory = v.category.toLowerCase().includes(query);
      const matchTags = v.tags?.some((t) => t.toLowerCase().includes(query));
      return matchTitle || matchDesc || matchCategory || matchTags;
    });
  }, [videos, searchQuery]);

  // Sort filtered results
  const sortedVideos = useMemo(() => {
    const list = [...filteredVideos];
    if (sortBy === 'views') {
      return list.sort((a, b) => b.views - a.views);
    }
    if (sortBy === 'likes') {
      return list.sort((a, b) => b.likes - a.likes);
    }
    if (sortBy === 'newest') {
      // By default initial order is latest first
      return list;
    }
    return list;
  }, [filteredVideos, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Header and Controls */}
      <div className="flex flex-col gap-5 pb-6 border-b border-zinc-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              id="search-back-home-btn"
              onClick={onBackToHome}
              className="p-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 transition-colors cursor-pointer"
              title="Return to Home"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-lg sm:text-xl font-bold text-zinc-100 flex items-center gap-2">
                <Search className="w-5 h-5 text-red-500" />
                <span>Search Channel Videos</span>
              </h1>
              <p className="text-xs text-zinc-400 mt-0.5">
                {searchQuery ? (
                  <>Showing {filteredVideos.length} matching video{filteredVideos.length === 1 ? '' : 's'} for &ldquo;<span className="text-zinc-200 font-medium">{searchQuery}</span>&rdquo;</>
                ) : (
                  <>Search all {videos.length} videos uploaded by {CREATOR_PROFILE.name}</>
                )}
              </p>
            </div>
          </div>

          {/* Sort selector */}
          <div className="flex items-center gap-2 self-start sm:self-center">
            <SlidersHorizontal className="w-4 h-4 text-zinc-400" />
            <span className="text-xs text-zinc-400 font-medium">Sort:</span>
            <select
              id="search-sort-select"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs text-zinc-200 font-medium focus:outline-none focus:ring-1 focus:ring-red-500 cursor-pointer"
            >
              <option value="relevance">Relevance</option>
              <option value="newest">Latest Uploads</option>
              <option value="views">Most Viewed</option>
              <option value="likes">Most Liked</option>
            </select>
          </div>
        </div>

        {/* Dedicated Search Page Input Bar */}
        <div className="relative w-full">
          <div className="relative flex items-center">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-zinc-400">
              <Search className="w-5 h-5 text-red-500" />
            </div>
            <input
              id="search-page-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Type to search videos by title (e.g. Lighting, Setup, Color, 24fps)..."
              autoFocus
              className="w-full pl-12 pr-12 py-3 bg-zinc-900/90 border border-zinc-700/90 rounded-2xl text-sm sm:text-base text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all shadow-inner"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 p-1 text-zinc-400 hover:text-zinc-200 rounded-full hover:bg-zinc-800 transition-colors"
                title="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick title keyword suggestions */}
          <div className="flex items-center gap-1.5 mt-2.5 overflow-x-auto pb-1 text-xs scrollbar-none">
            <span className="text-zinc-500 text-[11px] font-medium mr-1 shrink-0">Popular:</span>
            {['Lighting', 'Desk Setup', '24fps', 'Color Grading', 'Sound Design', 'Architecture'].map((tag) => (
              <button
                key={tag}
                onClick={() => setSearchQuery(tag)}
                className="px-2.5 py-1 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-zinc-200 text-xs transition-colors shrink-0 cursor-pointer"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Results Container */}
      <div className="mt-6">
        {sortedVideos.length > 0 ? (
          <div className="space-y-4">
            {sortedVideos.map((video) => (
              <VideoCard
                key={video.id}
                video={video}
                onSelect={onSelectVideo}
                layout="list"
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 px-4 bg-zinc-900/30 border border-zinc-800/80 rounded-2xl max-w-lg mx-auto">
            <div className="w-12 h-12 rounded-full bg-zinc-800 text-zinc-400 flex items-center justify-center mx-auto mb-3">
              <Frown className="w-6 h-6" />
            </div>
            <h3 className="text-base font-semibold text-zinc-200">
              No videos found matching &ldquo;{searchQuery}&rdquo;
            </h3>
            <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
              Try searching with different keywords like &quot;lighting&quot;, &quot;desk&quot;, &quot;color&quot;, or browse all videos on the home page.
            </p>
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                onClick={() => setSearchQuery('')}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-xl text-xs font-semibold"
              >
                Clear Search Query
              </button>
              <button
                onClick={onBackToHome}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-semibold"
              >
                Go to Home
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
