import React, { useState, useEffect } from 'react';
import { CheckCircle2, Bell, BellRing, Sparkles, Film, Eye, ThumbsUp } from 'lucide-react';
import { CREATOR_PROFILE, formatCount } from '../utils/storage';
import { Video } from '../types';

interface ChannelHeaderProps {
  videos: Video[];
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
}

export const ChannelHeader: React.FC<ChannelHeaderProps> = ({
  videos,
  activeCategory,
  setActiveCategory,
}) => {
  const [isSubscribed, setIsSubscribed] = useState(() => {
    return localStorage.getItem('mini_yt_is_subscribed') === 'true';
  });
  const [subCount, setSubCount] = useState(() => {
    const saved = localStorage.getItem('mini_yt_is_subscribed') === 'true';
    return CREATOR_PROFILE.subscribersCount + (saved ? 1 : 0);
  });

  const handleSubscribeToggle = () => {
    const nextState = !isSubscribed;
    setIsSubscribed(nextState);
    setSubCount((prev) => (nextState ? prev + 1 : prev - 1));
    localStorage.setItem('mini_yt_is_subscribed', nextState ? 'true' : 'false');
  };

  const totalViews = videos.reduce((acc, v) => acc + v.views, 0);
  const totalLikes = videos.reduce((acc, v) => acc + v.likes, 0);

  // Extract all unique categories
  const categories = ['All', ...Array.from(new Set(videos.map((v) => v.category)))];

  return (
    <div className="w-full bg-zinc-900/50 border-b border-zinc-800/80 mb-6">
      {/* Banner image with gentle gradient overlay */}
      <div className="relative h-40 sm:h-52 md:h-64 w-full overflow-hidden bg-zinc-950">
        <img
          src={CREATOR_PROFILE.bannerUrl}
          alt={`${CREATOR_PROFILE.name} channel banner`}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-60 brightness-95"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent" />
        
        {/* Banner badge */}
        <div className="absolute top-4 right-4 bg-zinc-950/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-zinc-700/50 text-xs text-zinc-300 flex items-center gap-1.5 shadow-lg">
          <Film className="w-3.5 h-3.5 text-red-500" />
          <span>Official Single Creator Hub</span>
        </div>
      </div>

      {/* Creator Info Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 -mt-12 sm:-mt-16 pb-6 relative z-10">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4">
          <div className="flex items-start sm:items-center gap-4">
            {/* Avatar */}
            <div className="relative group">
              <img
                src={CREATOR_PROFILE.avatarUrl}
                alt={CREATOR_PROFILE.name}
                referrerPolicy="no-referrer"
                className="w-20 h-20 sm:w-28 sm:h-28 rounded-full object-cover ring-4 ring-zinc-950 shadow-2xl"
              />
              <span className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-red-600 flex items-center justify-center text-white ring-2 ring-zinc-950">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </span>
            </div>

            {/* Creator Text */}
            <div className="pt-2 sm:pt-0">
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-white tracking-tight">
                  {CREATOR_PROFILE.name}
                </h1>
                <CheckCircle2
                  className="w-5 h-5 text-zinc-400"
                  title="Verified Creator"
                />
              </div>

              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs sm:text-sm text-zinc-400 mt-1">
                <span className="font-medium text-zinc-300">{CREATOR_PROFILE.handle}</span>
                <span>•</span>
                <span>{formatCount(subCount)} subscribers</span>
                <span>•</span>
                <span>{videos.length} videos</span>
              </div>

              <p className="text-xs sm:text-sm text-zinc-300 mt-2 max-w-2xl line-clamp-2 leading-relaxed">
                {CREATOR_PROFILE.bio}
              </p>
            </div>
          </div>

          {/* Subscribe Action & Channel Metrics */}
          <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end shrink-0 pt-2 sm:pt-0">
            {/* Quick stats badges */}
            <div className="hidden lg:flex items-center gap-4 px-4 py-2 bg-zinc-900 rounded-xl border border-zinc-800 text-xs text-zinc-400 mr-2">
              <div className="flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-zinc-400" />
                <span>{formatCount(totalViews)} views</span>
              </div>
              <div className="w-px h-3 bg-zinc-800" />
              <div className="flex items-center gap-1.5">
                <ThumbsUp className="w-3.5 h-3.5 text-zinc-400" />
                <span>{formatCount(totalLikes)} likes</span>
              </div>
            </div>

            {/* Subscribe Button */}
            <button
              id="creator-subscribe-btn"
              onClick={handleSubscribeToggle}
              className={`flex items-center justify-center gap-2 px-6 py-2.5 rounded-full text-sm font-semibold transition-all duration-200 cursor-pointer shadow-lg ${
                isSubscribed
                  ? 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700'
                  : 'bg-white hover:bg-zinc-200 text-zinc-950 active:scale-95'
              }`}
            >
              {isSubscribed ? (
                <>
                  <BellRing className="w-4 h-4 text-red-500" />
                  <span>Subscribed</span>
                </>
              ) : (
                <>
                  <Bell className="w-4 h-4" />
                  <span>Subscribe</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Category Pills Bar */}
        <div className="mt-6 pt-4 border-t border-zinc-800/60 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeCategory === cat
                  ? 'bg-zinc-100 text-zinc-950 font-semibold shadow-sm'
                  : 'bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300 border border-zinc-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
