import { Video, CreatorProfile, Comment } from '../types';

const DB_NAME = 'MiniYouTubeDB';
const DB_VERSION = 1;
const STORE_NAME = 'video_blobs';

const STORAGE_KEY_VIDEOS = 'mini_yt_videos_data';
const STORAGE_KEY_LIKES = 'mini_yt_liked_ids';
const STORAGE_KEY_COMMENTS = 'mini_yt_comments_data';
const STORAGE_KEY_ADMIN_AUTH = 'mini_yt_admin_session';
const STORAGE_KEY_ADMIN_PASSWORD = 'mini_yt_admin_pwd';

export const DEFAULT_ADMIN_PASSWORD = 'creator2025';

export const CREATOR_PROFILE: CreatorProfile = {
  name: 'Marcus Vance',
  handle: '@marcusvance',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=240&auto=format&fit=crop&q=80',
  bannerUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1600&auto=format&fit=crop&q=80',
  subscribersCount: 142000,
  bio: 'Filmmaker, visual storyteller & creative technologist. Sharing deep-dives on cinematography, digital gear, code art, and creative independence.',
  verified: true,
  joinDate: 'March 2023',
};

export const INITIAL_VIDEOS: Video[] = [
  {
    id: 'vid-1',
    title: 'The Art of Cinematic Lighting: 3-Point Setup Deep Dive',
    description: `In this episode, we break down lighting techniques used by Hollywood cinematographers on a budget. We cover key light placement, diffusion ratios, color temperature contrast, and how to create natural-looking separation from the background.

Chapters:
0:00 - Introduction & The Core Philosophy
1:45 - Key Light Angle & Falloff
4:10 - Negative Fill & Shadow Shaping
7:30 - Color Contrast with Rim Lights
10:15 - Final Scene Comparison

Shot on modern cinema gear with prime glass. Let me know in the comments which lighting setup you prefer!`,
    thumbnailUrl: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=800&auto=format&fit=crop&q=80',
    videoUrl: 'https://media.w3.org/2010/05/sintel/trailer.mp4',
    sourceType: 'url',
    duration: '00:52',
    views: 89400,
    likes: 4210,
    uploadedAt: '2 days ago',
    category: 'Cinematography',
    tags: ['filmmaking', 'lighting', 'cinema', 'camera'],
  },
  {
    id: 'vid-2',
    title: 'Building a Clean Desk Setup for Creative Coding & Video Editing',
    description: `A comprehensive walkthrough of my current workspace architecture. Everything from custom acoustic wood panels and cable management conduits to monitor calibration and dual-OS workflow shortcuts.

Gear featured:
- 34" Ultrawide 5K2K OLED display
- Custom walnut standing desk with embedded power channels
- Genelec 8030C studio monitors
- Keychron mechanical keyboard

Drop any questions below about mounting and cable trays!`,
    thumbnailUrl: 'https://images.unsplash.com/photo-1593062096033-9a26b09da705?w=800&auto=format&fit=crop&q=80',
    videoUrl: 'https://vjs.zencdn.net/v/oceans.mp4',
    sourceType: 'url',
    duration: '00:46',
    views: 134200,
    likes: 8920,
    uploadedAt: '1 week ago',
    category: 'Studio Tour',
    tags: ['desksetup', 'productivity', 'workspace', 'editing'],
  },
  {
    id: 'vid-3',
    title: 'Why 24fps Still Matters in Modern Digital Cinema',
    description: `Why do movies still look and feel like "movies" at 24 frames per second, while 60fps or 120fps often feels like a soap opera or sports broadcast? Let's explore the psycho-visual phenomena behind motion blur, the 180-degree shutter rule, and the emotional resonance of cinematic cadence.`,
    thumbnailUrl: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&auto=format&fit=crop&q=80',
    videoUrl: 'https://media.w3.org/2010/05/bunny/trailer.mp4',
    sourceType: 'url',
    duration: '00:33',
    views: 67800,
    likes: 3410,
    uploadedAt: '2 weeks ago',
    category: 'Theory & Craft',
    tags: ['filmmaking', 'fps', 'cinematography', 'optics'],
  },
  {
    id: 'vid-4',
    title: 'Color Grading Masterclass: Transforming Flat LOG to Rich Film Looks',
    description: `Step-by-step masterclass taking RAW and Log footage straight to rich, textured film emulation. We explore DaVinci Resolve color managed pipelines, split toning, subtractive color saturation, and organic grain overlay balancing.`,
    thumbnailUrl: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?w=800&auto=format&fit=crop&q=80',
    videoUrl: 'https://media.w3.org/2010/05/video/movie_300.mp4',
    sourceType: 'url',
    duration: '00:12',
    views: 215000,
    likes: 14600,
    uploadedAt: '3 weeks ago',
    category: 'Color Grading',
    tags: ['colorgrading', 'davinci', 'postproduction'],
  },
  {
    id: 'vid-5',
    title: 'Field Recording in the Pacific Northwest: Capturing Pure Ambient Audio',
    description: `Join me on a 4-day solo expedition through the Olympic National Park rainforest. Equipped with binaural and ambisonic microphones, we capture the rarest acoustic quiet and lush rainfall soundscapes. Headphones strongly recommended!`,
    thumbnailUrl: 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=800&auto=format&fit=crop&q=80',
    videoUrl: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4',
    sourceType: 'url',
    duration: '00:05',
    views: 45200,
    likes: 2980,
    uploadedAt: '1 month ago',
    category: 'Sound Design',
    tags: ['sounddesign', 'fieldrecording', 'audio', 'nature'],
  },
  {
    id: 'vid-6',
    title: 'How I Built My Own Creator Video Hub (Design & Architecture)',
    description: `As a single content creator, having a clean, distraction-free home for my work outside of algorithmic feeds has been a dream. Here is the entire tech stack, video streaming pipeline, and design philosophy behind this very website!`,
    thumbnailUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80',
    videoUrl: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm',
    sourceType: 'url',
    duration: '00:05',
    views: 112000,
    likes: 7420,
    uploadedAt: '1 month ago',
    category: 'Behind The Scenes',
    tags: ['tech', 'coding', 'webdev', 'creator'],
  },
];

// Open or get IndexedDB for storing uploaded video Blobs
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// Store a video blob in IndexedDB
export async function saveVideoBlob(id: string, file: Blob): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(file, id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Failed to save video blob to IndexedDB:', err);
    throw err;
  }
}

// Get video blob from IndexedDB
export async function getVideoBlob(id: string): Promise<Blob | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Failed to get video blob from IndexedDB:', err);
    return null;
  }
}

// Delete video blob from IndexedDB
export async function deleteVideoBlob(id: string): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Failed to delete video blob from IndexedDB:', err);
  }
}

// Videos LocalStorage operations
export function getStoredVideos(): Video[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_VIDEOS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_VIDEOS, JSON.stringify(INITIAL_VIDEOS));
      return INITIAL_VIDEOS;
    }
    const parsed: Video[] = JSON.parse(raw);
    
    // Automatically repair legacy broken video URLs if stored in browser
    let hasBrokenUrl = false;
    const sanitized = parsed.map((v) => {
      if (v.videoUrl && v.videoUrl.includes('commondatastorage.googleapis.com')) {
        hasBrokenUrl = true;
        const matchingInitial = INITIAL_VIDEOS.find((iv) => iv.id === v.id);
        if (matchingInitial) {
          return { ...v, videoUrl: matchingInitial.videoUrl, duration: matchingInitial.duration };
        }
        return { ...v, videoUrl: 'https://vjs.zencdn.net/v/oceans.mp4' };
      }
      return v;
    });

    if (hasBrokenUrl) {
      localStorage.setItem(STORAGE_KEY_VIDEOS, JSON.stringify(sanitized));
      return sanitized;
    }

    return parsed;
  } catch {
    return INITIAL_VIDEOS;
  }
}

export function saveVideos(videos: Video[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_VIDEOS, JSON.stringify(videos));
  } catch (err) {
    console.error('Failed to save videos to localStorage', err);
  }
}

export function addVideo(video: Video): void {
  const current = getStoredVideos();
  const updated = [video, ...current];
  saveVideos(updated);
}

export function deleteVideo(id: string): void {
  const current = getStoredVideos();
  const updated = current.filter((v) => v.id !== id);
  saveVideos(updated);
  deleteVideoBlob(id).catch(console.error);
}

// User liked video IDs
export function getLikedVideoIds(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_LIKES);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function toggleLikeVideo(videoId: string): { isLiked: boolean; newLikesCount: number } {
  const likedIds = getLikedVideoIds();
  const isCurrentlyLiked = likedIds.includes(videoId);
  const updatedLikedIds = isCurrentlyLiked
    ? likedIds.filter((id) => id !== videoId)
    : [...likedIds, videoId];

  localStorage.setItem(STORAGE_KEY_LIKES, JSON.stringify(updatedLikedIds));

  const videos = getStoredVideos();
  let newLikesCount = 0;
  const updatedVideos = videos.map((v) => {
    if (v.id === videoId) {
      newLikesCount = Math.max(0, isCurrentlyLiked ? v.likes - 1 : v.likes + 1);
      return { ...v, likes: newLikesCount };
    }
    return v;
  });

  saveVideos(updatedVideos);
  return { isLiked: !isCurrentlyLiked, newLikesCount };
}

export function incrementViews(videoId: string): number {
  const videos = getStoredVideos();
  let updatedViews = 0;
  const updatedVideos = videos.map((v) => {
    if (v.id === videoId) {
      updatedViews = v.views + 1;
      return { ...v, views: updatedViews };
    }
    return v;
  });
  saveVideos(updatedVideos);
  return updatedViews;
}

// Comments
export function getStoredComments(videoId: string): Comment[] {
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY_COMMENTS}_${videoId}`);
    if (!raw) {
      // Default seed comments for initial videos
      const initialComments: Comment[] = [
        {
          id: `c-1-${videoId}`,
          videoId,
          author: 'Elena Rostova',
          avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80',
          content: 'The lighting breakdown around the 4 minute mark completely changed how I look at negative fill. Brilliant production quality!',
          timestamp: '1 day ago',
          likes: 34,
        },
        {
          id: `c-2-${videoId}`,
          videoId,
          author: 'David Chen',
          avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
          content: 'Always inspiring to watch your videos Marcus. Clean, actionable, and visually stunning.',
          timestamp: '3 days ago',
          likes: 19,
        },
      ];
      localStorage.setItem(`${STORAGE_KEY_COMMENTS}_${videoId}`, JSON.stringify(initialComments));
      return initialComments;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function addComment(videoId: string, comment: Comment): Comment[] {
  const current = getStoredComments(videoId);
  const updated = [comment, ...current];
  localStorage.setItem(`${STORAGE_KEY_COMMENTS}_${videoId}`, JSON.stringify(updated));
  return updated;
}

// Admin Authentication
export function getAdminPassword(): string {
  return localStorage.getItem(STORAGE_KEY_ADMIN_PASSWORD) || DEFAULT_ADMIN_PASSWORD;
}

export function setAdminPassword(newPassword: string): void {
  localStorage.setItem(STORAGE_KEY_ADMIN_PASSWORD, newPassword);
}

export function isAdminAuthenticated(): boolean {
  return sessionStorage.getItem(STORAGE_KEY_ADMIN_AUTH) === 'true';
}

export function setAdminAuthenticated(auth: boolean): void {
  if (auth) {
    sessionStorage.setItem(STORAGE_KEY_ADMIN_AUTH, 'true');
  } else {
    sessionStorage.removeItem(STORAGE_KEY_ADMIN_AUTH);
  }
}

// Video Helper for YouTube / URL detection
export function parseVideoSource(inputUrl: string): { type: 'youtube' | 'url'; embedUrl: string } {
  const ytRegex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i;
  const match = inputUrl.match(ytRegex);
  if (match && match[1]) {
    return {
      type: 'youtube',
      embedUrl: `https://www.youtube.com/embed/${match[1]}?autoplay=1&rel=0`,
    };
  }
  return {
    type: 'url',
    embedUrl: inputUrl,
  };
}

// Number formatting helpers
export function formatCount(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
  }
  return num.toString();
}
