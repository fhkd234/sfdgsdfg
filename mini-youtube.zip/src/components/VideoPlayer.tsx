import React, { useEffect, useState, useRef } from 'react';
import { AlertCircle, Play, Loader2, RotateCcw, ExternalLink, Sparkles } from 'lucide-react';
import { Video } from '../types';
import { getVideoBlob, parseVideoSource } from '../utils/storage';

interface VideoPlayerProps {
  video: Video;
  onEnded?: () => void;
}

const BACKUP_DEMO_STREAM = 'https://vjs.zencdn.net/v/oceans.mp4';

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ video, onEnded }) => {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [loadingBlob, setLoadingBlob] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [useBackupStream, setUseBackupStream] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Reset states when video changes
  useEffect(() => {
    setHasError(false);
    setUseBackupStream(false);
  }, [video.id]);

  // Parse if it's a YouTube link
  const parsedSource = parseVideoSource(video.videoUrl);

  useEffect(() => {
    let active = true;
    let createdUrl: string | null = null;
    setHasError(false);

    if (video.sourceType === 'file' || video.videoUrl.startsWith('indexeddb:')) {
      setLoadingBlob(true);
      const blobKey = video.videoUrl.replace('indexeddb:', '');

      getVideoBlob(blobKey)
        .then((blob) => {
          if (!active) return;
          if (blob) {
            createdUrl = URL.createObjectURL(blob);
            setBlobUrl(createdUrl);
          } else {
            setHasError(true);
          }
          setLoadingBlob(false);
        })
        .catch((err) => {
          console.error('Error loading video blob:', err);
          if (active) {
            setHasError(true);
            setLoadingBlob(false);
          }
        });
    } else {
      setBlobUrl(null);
      setLoadingBlob(false);
    }

    return () => {
      active = false;
      if (createdUrl) {
        URL.revokeObjectURL(createdUrl);
      }
    };
  }, [video.id, video.sourceType, video.videoUrl]);

  // Safe playback start after video src loads
  useEffect(() => {
    if (videoRef.current && !hasError) {
      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          // Auto-play was prevented by the browser policy; user will click play on controls
        });
      }
    }
  }, [blobUrl, video.videoUrl, useBackupStream]);

  if (parsedSource.type === 'youtube') {
    return (
      <div className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-zinc-800">
        <iframe
          src={parsedSource.embedUrl}
          title={video.title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          className="w-full h-full border-0"
        />
      </div>
    );
  }

  if (loadingBlob) {
    return (
      <div className="relative w-full aspect-video bg-zinc-950 rounded-2xl overflow-hidden flex flex-col items-center justify-center border border-zinc-800 text-zinc-400">
        <Loader2 className="w-8 h-8 animate-spin text-red-500 mb-3" />
        <p className="text-sm font-medium">Loading creator video from storage...</p>
      </div>
    );
  }

  if (hasError) {
    return (
      <div className="relative w-full aspect-video bg-zinc-950 rounded-2xl overflow-hidden flex flex-col items-center justify-center border border-zinc-800 text-zinc-400 p-6 text-center">
        <AlertCircle className="w-10 h-10 text-red-500 mb-3" />
        <h4 className="text-zinc-100 font-semibold mb-1">Video Stream Unavailable</h4>
        <p className="text-xs text-zinc-400 max-w-md mb-5 leading-relaxed">
          The original video stream could not be loaded directly by the browser. You can retry, play the backup demo stream, or open the link directly.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={() => {
              setHasError(false);
              if (videoRef.current) {
                videoRef.current.load();
              }
            }}
            className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Retry Playback</span>
          </button>

          <button
            onClick={() => {
              setHasError(false);
              setUseBackupStream(true);
            }}
            className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-md shadow-red-600/30"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            <span>Play Backup Stream</span>
          </button>

          {!video.videoUrl.startsWith('indexeddb:') && (
            <a
              href={video.videoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Direct Link</span>
            </a>
          )}
        </div>
      </div>
    );
  }

  const effectiveVideoSrc = useBackupStream
    ? BACKUP_DEMO_STREAM
    : blobUrl || video.videoUrl;

  return (
    <div className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-zinc-800 group">
      <video
        ref={videoRef}
        key={effectiveVideoSrc}
        src={effectiveVideoSrc}
        poster={video.thumbnailUrl}
        controls
        playsInline
        preload="metadata"
        onEnded={onEnded}
        onError={() => setHasError(true)}
        className="w-full h-full object-contain focus:outline-none"
      >
        Your browser does not support HTML5 video playback.
      </video>
    </div>
  );
};
