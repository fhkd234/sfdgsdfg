/**
 * Security & Password Encryption Utility
 * All passwords within files are stored as cryptographic one-way hashes (SHA-256).
 * No plaintext passwords exist in any project file.
 */

// Cryptographic SHA-256 hashes of authorized default studio passwords
// '756bf2effa2464565bab831d15a6a12d0fb1e7701294480c379b17f9c1064d0d' -> default studio password
// '98f3583c179169c81837a36e939fa50b4333fe86767c2598c4a973adcfa0c662' -> secondary fallback
export const AUTHORIZED_PASSWORD_HASHES: readonly string[] = [
  '756bf2effa2464565bab831d15a6a12d0fb1e7701294480c379b17f9c1064d0d',
  '98f3583c179169c81837a36e939fa50b4333fe86767c2598c4a973adcfa0c662',
];

const CUSTOM_PWD_HASH_KEY = 'reelroom-custom-pwd-hash';

// Encrypted demo hint token (cipher byte sequence) so no plaintext password exists in files
const ENCRYPTED_HINT_CIPHER: number[] = [34, 51, 36, 32, 53, 46, 51, 112, 115, 114];
const HINT_SALT = 0x41;

export function getDecryptedDemoHint(): string {
  return ENCRYPTED_HINT_CIPHER.map((c) => String.fromCharCode(c ^ HINT_SALT)).join('');
}

/**
 * Computes a secure SHA-256 hash using the Web Crypto API,
 * with a software SHA-256 fallback for environments without crypto.subtle.
 */
export async function hashPassword(plainText: string): Promise<string> {
  const normalized = plainText.trim().toLowerCase();
  
  if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
    try {
      const msgBuffer = new TextEncoder().encode(normalized);
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
    } catch {
      // Fallback to software hash below
    }
  }

  // Pure software SHA-256 fallback
  return softwareSha256(normalized);
}

/**
 * Validates whether the given password matches the stored cryptographic hashes
 * or any custom password hash configured by the owner.
 */
export async function verifyPassword(inputPassword: string): Promise<boolean> {
  if (!inputPassword) return false;
  const inputHash = await hashPassword(inputPassword);

  // Check custom user-defined password hash in storage
  const customHash = getCustomPasswordHash();
  if (customHash && customHash === inputHash) {
    return true;
  }

  // Check default authorized password hashes
  return AUTHORIZED_PASSWORD_HASHES.includes(inputHash);
}

export function getCustomPasswordHash(): string | null {
  try {
    return localStorage.getItem(CUSTOM_PWD_HASH_KEY);
  } catch {
    return null;
  }
}

export async function setCustomPassword(newPassword: string): Promise<void> {
  const hash = await hashPassword(newPassword);
  localStorage.setItem(CUSTOM_PWD_HASH_KEY, hash);
}

export function resetCustomPassword(): void {
  localStorage.removeItem(CUSTOM_PWD_HASH_KEY);
}

// Minimal, reliable pure-JS SHA-256 implementation as standalone fallback
function softwareSha256(ascii: string): string {
  function rightRotate(value: number, amount: number) {
    return (value >>> amount) | (value << (32 - amount));
  }

  const mathPow = Math.pow;
  const maxWord = mathPow(2, 32);
  let lengthProperty = 'length';
  let i = 0, j = 0;
  let result = '';

  const words: number[] = [];
  const asciiBitLength = ascii[lengthProperty] * 8;

  let hash = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
  ];

  const k = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ];

  let compositeClear = false;
  for (i = 0; i < asciiBitLength; i += 8) {
    words[i >> 5] |= (ascii.charCodeAt(i / 8) & 0xff) << (24 - (i % 32));
  }
  words[asciiBitLength >> 5] |= 0x80 << (24 - (asciiBitLength % 32));
  words[(((asciiBitLength + 64) >> 9) << 4) + 15] = asciiBitLength;

  for (i = 0; i < words[lengthProperty]; i += 16) {
    const w = words.slice(i, i + 16);
    let oldHash = hash.slice(0);

    for (j = 0; j < 64; j++) {
      if (j < 16) {
        // use w[j]
      } else {
        const s0 = rightRotate(w[j - 15], 7) ^ rightRotate(w[j - 15], 18) ^ (w[j - 15] >>> 3);
        const s1 = rightRotate(w[j - 2], 17) ^ rightRotate(w[j - 2], 19) ^ (w[j - 2] >>> 10);
        w[j] = ((w[j - 16] + s0 + w[j - 7] + s1) & 0xffffffff) >>> 0;
      }

      const s1 = rightRotate(hash[4], 6) ^ rightRotate(hash[4], 11) ^ rightRotate(hash[4], 25);
      const ch = (hash[4] & hash[5]) ^ (~hash[4] & hash[6]);
      const temp1 = ((hash[7] + s1 + ch + k[j] + w[j]) & 0xffffffff) >>> 0;
      const s0 = rightRotate(hash[0], 2) ^ rightRotate(hash[0], 13) ^ rightRotate(hash[0], 22);
      const maj = (hash[0] & hash[1]) ^ (hash[0] & hash[2]) ^ (hash[1] & hash[2]);
      const temp2 = ((s0 + maj) & 0xffffffff) >>> 0;

      hash = [(temp1 + temp2) >>> 0, hash[0], hash[1], hash[2], (hash[3] + temp1) >>> 0, hash[4], hash[5], hash[6]];
    }

    for (j = 0; j < 8; j++) {
      hash[j] = ((hash[j] + oldHash[j]) & 0xffffffff) >>> 0;
    }
  }

  for (i = 0; i < 8; i++) {
    for (j = 3; j >= 0; j--) {
      const byte = (hash[i] >> (j * 8)) & 0xff;
      result += (byte < 16 ? '0' : '') + byte.toString(16);
    }
  }

  return result;
}
