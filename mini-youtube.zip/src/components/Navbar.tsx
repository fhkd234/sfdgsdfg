import React, { useState, useEffect } from 'react';
import { Play, Search, X, Shield, Video as VideoIcon, ArrowLeft, Home, Sparkles } from 'lucide-react';
import { ActivePage } from '../types';
import { CREATOR_PROFILE } from '../utils/storage';

interface NavbarProps {
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onSearchSubmit: (query: string) => void;
  isAdminLoggedIn: boolean;
  onSelectVideoById?: (id: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePage,
  setActivePage,
  searchQuery,
  setSearchQuery,
  onSearchSubmit,
  isAdminLoggedIn,
}) => {
  const [localSearch, setLocalSearch] = useState(searchQuery);

  // Synchronize local search state with parent searchQuery
  useEffect(() => {
    setLocalSearch(searchQuery);
  }, [searchQuery]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchQuery(localSearch.trim());
    onSearchSubmit(localSearch.trim());
    setActivePage('search');
  };

  const handleClear = () => {
    setLocalSearch('');
    setSearchQuery('');
  };

  return (
    <header className="sticky top-0 z-40 bg-zinc-950/95 backdrop-blur-md border-b border-zinc-800/80 text-zinc-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Logo and Brand */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            id="nav-logo-btn"
            onClick={() => setActivePage('home')}
            className="flex items-center gap-2.5 group cursor-pointer text-left focus:outline-none focus:ring-2 focus:ring-red-500 rounded-lg p-1"
          >
            <div className="w-9 h-9 rounded-xl bg-red-600 flex items-center justify-center shadow-lg shadow-red-600/30 group-hover:scale-105 transition-transform">
              <Play className="w-5 h-5 fill-white text-white ml-0.5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-lg tracking-tight text-white flex items-center gap-1">
                  Mini<span className="text-red-500">Tube</span>
                </span>
                <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 border border-zinc-700/60">
                  Creator Hub
                </span>
              </div>
              <p className="text-xs text-zinc-400 leading-none truncate max-w-[140px] sm:max-w-[180px]">
                {CREATOR_PROFILE.name}
              </p>
            </div>
          </button>
        </div>

        {/* Search Bar */}
        <form
          onSubmit={handleSubmit}
          className="flex-1 max-w-xl mx-2 sm:mx-4 relative"
          role="search"
        >
          <div className="relative flex items-center">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              id="global-search-input"
              type="text"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder="Search creator videos by title..."
              className="w-full pl-10 pr-20 py-2 text-sm bg-zinc-900 border border-zinc-700/80 rounded-full text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all shadow-inner"
            />
            {localSearch && (
              <button
                type="button"
                onClick={handleClear}
                className="absolute right-14 text-zinc-400 hover:text-zinc-200 p-1"
                title="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              id="global-search-submit-btn"
              type="submit"
              className="absolute right-1 top-1 bottom-1 px-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-full text-xs font-medium flex items-center gap-1 transition-colors border border-zinc-700/50 cursor-pointer"
            >
              Search
            </button>
          </div>
        </form>

        {/* Actions & Creator Profile / Admin */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            id="nav-home-btn"
            onClick={() => setActivePage('home')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
              activePage === 'home'
                ? 'bg-zinc-800 text-white font-semibold'
                : 'text-zinc-300 hover:bg-zinc-800/60'
            }`}
          >
            <Home className="w-4 h-4" />
            <span className="hidden sm:inline">Home</span>
          </button>

          <button
            id="nav-search-page-btn"
            onClick={() => setActivePage('search')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
              activePage === 'search'
                ? 'bg-zinc-800 text-white font-semibold'
                : 'text-zinc-300 hover:bg-zinc-800/60'
            }`}
          >
            <Search className="w-4 h-4" />
            <span className="hidden sm:inline">Search</span>
          </button>

          {/* Admin Studio Button */}
          <button
            id="nav-admin-dashboard-btn"
            onClick={() => setActivePage('admin')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-medium transition-all cursor-pointer ${
              activePage === 'admin'
                ? 'bg-red-600 text-white shadow-md shadow-red-600/30 font-semibold'
                : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700/80'
            }`}
          >
            {isAdminLoggedIn ? (
              <VideoIcon className="w-4 h-4 text-red-400" />
            ) : (
              <Shield className="w-3.5 h-3.5 text-zinc-400" />
            )}
            <span className="whitespace-nowrap">
              {isAdminLoggedIn ? 'Creator Studio' : 'Owner Studio'}
            </span>
          </button>

          {/* Creator Profile Avatar / Quick Link */}
          <div
            className="flex items-center gap-2 pl-1 border-l border-zinc-800 cursor-pointer"
            onClick={() => setActivePage('home')}
            title={`${CREATOR_PROFILE.name} · Verified Creator`}
          >
            <img
              src={CREATOR_PROFILE.avatarUrl}
              alt={CREATOR_PROFILE.name}
              referrerPolicy="no-referrer"
              className="w-8 h-8 rounded-full object-cover ring-2 ring-zinc-700/80 hover:ring-red-500 transition-all"
            />
          </div>
        </div>
      </div>
    </header>
  );
};
