import React, { useState, useEffect } from 'react';
import {
  ThumbsUp,
  Share2,
  Bookmark,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  MessageSquare,
  ArrowLeft,
  Check,
  Send,
  Eye,
  Calendar,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { Video, Comment } from '../types';
import { VideoPlayer } from './VideoPlayer';
import { VideoCard } from './VideoCard';
import {
  CREATOR_PROFILE,
  formatCount,
  toggleLikeVideo,
  getLikedVideoIds,
  incrementViews,
  getStoredComments,
  addComment,
} from '../utils/storage';

interface WatchViewProps {
  video: Video;
  allVideos: Video[];
  onSelectVideo: (video: Video) => void;
  onBackToHome: () => void;
  onUpdateVideoInList: (updatedVideo: Video) => void;
}

export const WatchView: React.FC<WatchViewProps> = ({
  video,
  allVideos,
  onSelectVideo,
  onBackToHome,
  onUpdateVideoInList,
}) => {
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(video.likes);
  const [viewsCount, setViewsCount] = useState(video.views);
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);
  const [copiedToast, setCopiedToast] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newCommentText, setNewCommentText] = useState('');
  const [commenterName, setCommenterName] = useState('Community Member');
  const [isSubscribed, setIsSubscribed] = useState(() => {
    return localStorage.getItem('mini_yt_is_subscribed') === 'true';
  });

  // Track initial like status and view increment on mount
  useEffect(() => {
    const likedList = getLikedVideoIds();
    setIsLiked(likedList.includes(video.id));
    setLikesCount(video.likes);

    // Increment view count for the session
    const updatedViews = incrementViews(video.id);
    setViewsCount(updatedViews);

    // Load comments
    const loadedComments = getStoredComments(video.id);
    setComments(loadedComments);

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [video.id]);

  const handleLikeToggle = () => {
    const res = toggleLikeVideo(video.id);
    setIsLiked(res.isLiked);
    setLikesCount(res.newLikesCount);
    onUpdateVideoInList({ ...video, likes: res.newLikesCount });
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedToast(true);
    setTimeout(() => setCopiedToast(false), 2500);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;

    const newC: Comment = {
      id: `comm-${Date.now()}`,
      videoId: video.id,
      author: commenterName.trim() || 'Viewer',
      avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80',
      content: newCommentText.trim(),
      timestamp: 'Just now',
      likes: 0,
    };

    const updated = addComment(video.id, newC);
    setComments(updated);
    setNewCommentText('');
  };

  // Related videos (all except current)
  const relatedVideos = allVideos.filter((v) => v.id !== video.id);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
      {/* Back button */}
      <button
        id="watch-back-home-btn"
        onClick={onBackToHome}
        className="inline-flex items-center gap-2 mb-4 text-xs sm:text-sm font-medium text-zinc-400 hover:text-white transition-colors cursor-pointer py-1.5 px-3 rounded-lg hover:bg-zinc-900 border border-transparent hover:border-zinc-800"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Video Gallery</span>
      </button>

      {/* Main Watch Layout: Player + Details on left, Up Next on right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Columns: Video Player, Title, Creator bar, Description, Comments */}
        <div className="lg:col-span-2 space-y-4">
          {/* 1. Video Player */}
          <div id="active-video-player-container">
            <VideoPlayer video={video} />
          </div>

          {/* 2. Video Title */}
          <h1
            id="watch-video-title"
            className="text-xl sm:text-2xl font-bold text-zinc-100 tracking-tight leading-snug pt-1"
          >
            {video.title}
          </h1>

          {/* 3. Creator Channel Bar & Actions (Like Button) */}
          <div className="flex flex-wrap items-center justify-between gap-4 py-2 border-b border-zinc-800/80">
            {/* Creator profile card */}
            <div className="flex items-center gap-3">
              <img
                src={CREATOR_PROFILE.avatarUrl}
                alt={CREATOR_PROFILE.name}
                referrerPolicy="no-referrer"
                className="w-11 h-11 rounded-full object-cover ring-2 ring-zinc-800"
              />
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-zinc-100 text-sm sm:text-base">
                    {CREATOR_PROFILE.name}
                  </span>
                  <CheckCircle2 className="w-4 h-4 text-zinc-400" />
                </div>
                <p className="text-xs text-zinc-400">
                  {formatCount(CREATOR_PROFILE.subscribersCount)} subscribers
                </p>
              </div>

              <button
                id="watch-subscribe-toggle-btn"
                onClick={() => {
                  const next = !isSubscribed;
                  setIsSubscribed(next);
                  localStorage.setItem('mini_yt_is_subscribed', next ? 'true' : 'false');
                }}
                className={`ml-2 px-4 py-2 rounded-full text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  isSubscribed
                    ? 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                    : 'bg-white text-zinc-950 hover:bg-zinc-200'
                }`}
              >
                {isSubscribed ? 'Subscribed' : 'Subscribe'}
              </button>
            </div>

            {/* Actions: LIKE BUTTON (Required), Share */}
            <div className="flex items-center gap-2">
              {/* The "Like" Button */}
              <button
                id="video-like-btn"
                onClick={handleLikeToggle}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 cursor-pointer ${
                  isLiked
                    ? 'bg-red-600 text-white shadow-lg shadow-red-600/25 ring-2 ring-red-500/50 scale-102'
                    : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800'
                }`}
                title={isLiked ? 'Unlike this video' : 'Like this video'}
              >
                <ThumbsUp
                  className={`w-4 h-4 transition-transform ${
                    isLiked ? 'fill-white scale-110' : ''
                  }`}
                />
                <span className="font-semibold">
                  {formatCount(likesCount)}
                </span>
                <span className="text-xs font-normal opacity-80 hidden sm:inline">
                  {isLiked ? 'Liked' : 'Like'}
                </span>
              </button>

              {/* Share button */}
              <button
                id="video-share-btn"
                onClick={handleShare}
                className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 transition-colors cursor-pointer"
                title="Share video link"
              >
                {copiedToast ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400 text-xs font-semibold">Copied!</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-4 h-4" />
                    <span className="text-xs font-normal hidden sm:inline">Share</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* 4. Description Box */}
          <div
            id="watch-video-description-box"
            onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
            className="bg-zinc-900/70 hover:bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 transition-all duration-200 cursor-pointer"
          >
            <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm font-semibold text-zinc-300 mb-2">
              <span className="flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-zinc-400" />
                {viewsCount.toLocaleString()} views
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-zinc-400" />
                {video.uploadedAt}
              </span>
              <span>•</span>
              <span className="text-red-400 font-medium">#{video.category}</span>
            </div>

            {/* Description content */}
            <div
              className={`text-xs sm:text-sm text-zinc-300 leading-relaxed whitespace-pre-line ${
                isDescriptionExpanded ? '' : 'line-clamp-3'
              }`}
            >
              {video.description}
            </div>

            <div className="mt-2 text-xs font-semibold text-zinc-400 flex items-center gap-1">
              {isDescriptionExpanded ? (
                <>
                  <span>Show less</span>
                  <ChevronUp className="w-3.5 h-3.5" />
                </>
              ) : (
                <>
                  <span>Show more</span>
                  <ChevronDown className="w-3.5 h-3.5" />
                </>
              )}
            </div>
          </div>

          {/* 5. Viewer Comments Section */}
          <div className="pt-4">
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="w-5 h-5 text-zinc-400" />
              <h2 className="text-lg font-bold text-zinc-100">
                Comments ({comments.length})
              </h2>
            </div>

            {/* Add Comment Input */}
            <form onSubmit={handleAddComment} className="flex gap-3 mb-6">
              <img
                src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80"
                alt="Your avatar"
                className="w-10 h-10 rounded-full object-cover shrink-0"
              />
              <div className="flex-1 space-y-2">
                <input
                  type="text"
                  value={newCommentText}
                  onChange={(e) => setNewCommentText(e.target.value)}
                  placeholder="Add a public comment for the creator..."
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-xs sm:text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-red-500 transition-all"
                />
                {newCommentText && (
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setNewCommentText('')}
                      className="px-3 py-1.5 text-xs text-zinc-400 hover:text-zinc-200"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
                    >
                      <Send className="w-3 h-3" />
                      Comment
                    </button>
                  </div>
                )}
              </div>
            </form>

            {/* Comments List */}
            <div className="space-y-4">
              {comments.map((c) => (
                <div key={c.id} className="flex gap-3 text-xs sm:text-sm">
                  <img
                    src={c.avatarUrl}
                    alt={c.author}
                    className="w-8 h-8 rounded-full object-cover shrink-0"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-zinc-200">{c.author}</span>
                      <span className="text-zinc-500 text-[11px]">{c.timestamp}</span>
                    </div>
                    <p className="text-zinc-300 mt-1 leading-relaxed">{c.content}</p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-zinc-500">
                      <button className="flex items-center gap-1 hover:text-zinc-300">
                        <ThumbsUp className="w-3 h-3" />
                        <span>{c.likes > 0 ? c.likes : ''}</span>
                      </button>
                      <button className="hover:text-zinc-300">Reply</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Up Next / Creator Videos Catalog */}
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
            <h3 className="font-bold text-zinc-100 text-base">
              More from {CREATOR_PROFILE.name}
            </h3>
            <span className="text-xs text-zinc-400 font-medium">
              {relatedVideos.length} videos
            </span>
          </div>

          <div className="space-y-4">
            {relatedVideos.map((item) => (
              <div
                key={item.id}
                onClick={() => onSelectVideo(item)}
                className="group flex gap-3 p-2 rounded-xl hover:bg-zinc-900/80 transition-colors cursor-pointer border border-transparent hover:border-zinc-800/80"
              >
                {/* 16:9 Mini Thumbnail */}
                <div className="relative w-40 aspect-video rounded-lg overflow-hidden bg-zinc-950 shrink-0">
                  <img
                    src={item.thumbnailUrl}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  />
                  <div className="absolute bottom-1 right-1 px-1 py-0.2 rounded bg-black/80 text-[10px] font-mono text-zinc-100 font-medium">
                    {item.duration}
                  </div>
                </div>

                {/* Meta */}
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs sm:text-sm font-semibold text-zinc-200 group-hover:text-red-400 line-clamp-2 leading-snug">
                    {item.title}
                  </h4>
                  <p className="text-[11px] text-zinc-400 mt-1 truncate">
                    {CREATOR_PROFILE.name}
                  </p>
                  <p className="text-[11px] text-zinc-500 mt-0.5">
                    {formatCount(item.views)} views • {item.uploadedAt}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
