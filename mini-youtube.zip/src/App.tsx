import React, { useState, useEffect } from 'react';
import { Video, ActivePage } from './types';
import {
  getStoredVideos,
  isAdminAuthenticated,
  CREATOR_PROFILE,
} from './utils/storage';
import { Navbar } from './components/Navbar';
import { HomeView } from './components/HomeView';
import { WatchView } from './components/WatchView';
import { SearchView } from './components/SearchView';
import { AdminDashboard } from './components/AdminDashboard';
import { Play, Shield, Heart, ExternalLink, Film } from 'lucide-react';

export default function App() {
  const [videos, setVideos] = useState<Video[]>(() => getStoredVideos());
  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(() => {
    const list = getStoredVideos();
    return list.length > 0 ? list[0] : null;
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(() => isAdminAuthenticated());

  // Check admin status periodically
  useEffect(() => {
    setIsAdminLoggedIn(isAdminAuthenticated());
  }, [activePage]);

  const handleSelectVideo = (video: Video) => {
    setSelectedVideo(video);
    setActivePage('watch');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearchSubmit = (query: string) => {
    setSearchQuery(query);
    setActivePage('search');
  };

  const handleBackToHome = () => {
    setActivePage('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleVideoAdded = (newVideo: Video) => {
    setVideos((prev) => [newVideo, ...prev]);
    setSelectedVideo(newVideo);
  };

  const handleVideoDeleted = (id: string) => {
    setVideos((prev) => prev.filter((v) => v.id !== id));
    if (selectedVideo?.id === id) {
      setSelectedVideo(videos.find((v) => v.id !== id) || null);
    }
  };

  const handleUpdateVideoInList = (updatedVideo: Video) => {
    setVideos((prev) =>
      prev.map((v) => (v.id === updatedVideo.id ? updatedVideo : v))
    );
    if (selectedVideo?.id === updatedVideo.id) {
      setSelectedVideo(updatedVideo);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-red-500/30 selection:text-red-200">
      {/* Top Navigation Bar */}
      <Navbar
        activePage={activePage}
        setActivePage={setActivePage}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onSearchSubmit={handleSearchSubmit}
        isAdminLoggedIn={isAdminLoggedIn}
      />

      {/* Main Content Area based on Active Page */}
      <main className="flex-1">
        {activePage === 'home' && (
          <HomeView
            videos={videos}
            onSelectVideo={handleSelectVideo}
            onOpenUpload={() => setActivePage('admin')}
          />
        )}

        {activePage === 'watch' && selectedVideo && (
          <WatchView
            video={selectedVideo}
            allVideos={videos}
            onSelectVideo={handleSelectVideo}
            onBackToHome={handleBackToHome}
            onUpdateVideoInList={handleUpdateVideoInList}
          />
        )}

        {activePage === 'search' && (
          <SearchView
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            videos={videos}
            onSelectVideo={handleSelectVideo}
            onBackToHome={handleBackToHome}
          />
        )}

        {activePage === 'admin' && (
          <AdminDashboard
            videos={videos}
            onVideoAdded={handleVideoAdded}
            onVideoDeleted={handleVideoDeleted}
            onViewVideo={handleSelectVideo}
            onClose={handleBackToHome}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-zinc-900 bg-zinc-950/80 py-8 text-xs text-zinc-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-red-600 flex items-center justify-center text-white">
              <Play className="w-3.5 h-3.5 fill-white" />
            </div>
            <span className="font-semibold text-zinc-300">Mini YouTube</span>
            <span>•</span>
            <span>Single Creator Platform for {CREATOR_PROFILE.name}</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setActivePage('home')}
              className="hover:text-zinc-200 transition-colors"
            >
              Home Grid
            </button>
            <button
              onClick={() => setActivePage('search')}
              className="hover:text-zinc-200 transition-colors"
            >
              Search
            </button>
            <button
              onClick={() => setActivePage('admin')}
              className="hover:text-red-400 transition-colors flex items-center gap-1"
            >
              <Shield className="w-3 h-3" />
              <span>Creator Studio</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
