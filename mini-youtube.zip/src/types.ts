export type VideoSourceType = 'url' | 'file' | 'youtube';

export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  videoUrl: string;
  sourceType: VideoSourceType;
  duration: string;
  views: number;
  likes: number;
  uploadedAt: string;
  category: string;
  tags?: string[];
}

export interface CreatorProfile {
  name: string;
  handle: string;
  avatarUrl: string;
  bannerUrl: string;
  subscribersCount: number;
  bio: string;
  verified: boolean;
  joinDate: string;
}

export interface Comment {
  id: string;
  videoId: string;
  author: string;
  avatarUrl: string;
  content: string;
  timestamp: string;
  likes: number;
}

export type ActivePage = 'home' | 'watch' | 'search' | 'admin';
