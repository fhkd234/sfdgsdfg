import React, { useState } from 'react';
import { Play, CheckCircle2, Clock } from 'lucide-react';
import { Video } from '../types';
import { CREATOR_PROFILE, formatCount } from '../utils/storage';

interface VideoCardProps {
  video: Video;
  onSelect: (video: Video) => void;
  layout?: 'grid' | 'list';
}

export const VideoCard: React.FC<VideoCardProps> = ({
  video,
  onSelect,
  layout = 'grid',
}) => {
  const [imageError, setImageError] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  // Fallback gradient/pattern if image fails to load
  const fallbackThumbnail =
    'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&auto=format&fit=crop&q=80';

  if (layout === 'list') {
    return (
      <div
        id={`video-card-${video.id}`}
        onClick={() => onSelect(video)}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className="group flex flex-col sm:flex-row gap-4 p-3 rounded-2xl bg-zinc-900/40 hover:bg-zinc-900 border border-transparent hover:border-zinc-800 transition-all duration-200 cursor-pointer"
      >
        {/* Thumbnail container 16:9 */}
        <div className="relative w-full sm:w-72 md:w-80 aspect-video rounded-xl overflow-hidden bg-zinc-950 shrink-0">
          <img
            src={imageError ? fallbackThumbnail : video.thumbnailUrl}
            alt={video.title}
            onError={() => setImageError(true)}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
          {/* Duration Badge */}
          <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 backdrop-blur-xs text-[11px] font-semibold text-zinc-100 font-mono tracking-tight">
            {video.duration || '10:00'}
          </div>

          {/* Hover Play overlay */}
          <div
            className={`absolute inset-0 bg-black/30 flex items-center justify-center transition-opacity duration-200 ${
              isHovered ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <div className="w-11 h-11 rounded-full bg-red-600/90 text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
              <Play className="w-5 h-5 fill-white text-white ml-0.5" />
            </div>
          </div>
        </div>

        {/* Video metadata */}
        <div className="flex-1 min-w-0 flex flex-col justify-start">
          <h3 className="text-base sm:text-lg font-semibold text-zinc-100 group-hover:text-red-400 transition-colors line-clamp-2 leading-snug">
            {video.title}
          </h3>

          <div className="flex items-center gap-2 mt-1.5 text-xs text-zinc-400">
            <span>{formatCount(video.views)} views</span>
            <span>•</span>
            <span>{video.uploadedAt}</span>
            <span>•</span>
            <span className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 font-medium">
              {video.category}
            </span>
          </div>

          <div className="flex items-center gap-2 mt-3 text-xs text-zinc-400">
            <img
              src={CREATOR_PROFILE.avatarUrl}
              alt={CREATOR_PROFILE.name}
              referrerPolicy="no-referrer"
              className="w-5 h-5 rounded-full object-cover"
            />
            <span className="hover:text-zinc-200 font-medium">{CREATOR_PROFILE.name}</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-zinc-400" />
          </div>

          <p className="text-xs text-zinc-400 line-clamp-2 mt-2 leading-relaxed">
            {video.description}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      id={`video-card-${video.id}`}
      onClick={() => onSelect(video)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group flex flex-col cursor-pointer"
    >
      {/* 16:9 Thumbnail preview with duration badge */}
      <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-zinc-900 border border-zinc-800/80 shadow-sm">
        <img
          src={imageError ? fallbackThumbnail : video.thumbnailUrl}
          alt={video.title}
          onError={() => setImageError(true)}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        {/* Duration badge */}
        <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/85 backdrop-blur-xs text-[11px] font-semibold text-zinc-100 font-mono tracking-tight">
          {video.duration || '12:00'}
        </div>

        {/* Hover play button overlay */}
        <div
          className={`absolute inset-0 bg-black/25 flex items-center justify-center transition-opacity duration-200 ${
            isHovered ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="w-10 h-10 rounded-full bg-red-600/95 text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
            <Play className="w-5 h-5 fill-white text-white ml-0.5" />
          </div>
        </div>
      </div>

      {/* Details Row: Creator Avatar + Title & Meta */}
      <div className="flex gap-3 mt-3 px-0.5">
        <img
          src={CREATOR_PROFILE.avatarUrl}
          alt={CREATOR_PROFILE.name}
          referrerPolicy="no-referrer"
          className="w-9 h-9 rounded-full object-cover shrink-0 ring-1 ring-zinc-700/60 mt-0.5"
        />
        <div className="flex-1 min-w-0">
          {/* Title */}
          <h2 className="text-sm font-semibold text-zinc-100 group-hover:text-red-400 transition-colors line-clamp-2 leading-snug">
            {video.title}
          </h2>

          {/* Channel Name */}
          <div className="flex items-center gap-1.5 text-xs text-zinc-400 mt-1">
            <span className="truncate hover:text-zinc-200">{CREATOR_PROFILE.name}</span>
            <CheckCircle2 className="w-3 h-3 text-zinc-400 shrink-0" />
          </div>

          {/* Views & Timestamp */}
          <div className="flex items-center gap-1.5 text-xs text-zinc-400 mt-0.5">
            <span>{formatCount(video.views)} views</span>
            <span>•</span>
            <span>{video.uploadedAt}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
