import React, { useState, useRef } from 'react';
import {
  Lock,
  Unlock,
  Upload,
  Link as LinkIcon,
  FileVideo,
  Image as ImageIcon,
  CheckCircle2,
  Trash2,
  ExternalLink,
  Eye,
  ThumbsUp,
  AlertCircle,
  Key,
  Shield,
  Sparkles,
  Play,
  Film,
  X,
} from 'lucide-react';
import { Video } from '../types';
import {
  getAdminPassword,
  setAdminPassword,
  isAdminAuthenticated,
  setAdminAuthenticated,
  saveVideoBlob,
  addVideo,
  deleteVideo,
  formatCount,
  parseVideoSource,
  CREATOR_PROFILE,
  DEFAULT_ADMIN_PASSWORD,
} from '../utils/storage';

interface AdminDashboardProps {
  videos: Video[];
  onVideoAdded: (newVideo: Video) => void;
  onVideoDeleted: (id: string) => void;
  onViewVideo: (video: Video) => void;
  onClose: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  videos,
  onVideoAdded,
  onVideoDeleted,
  onViewVideo,
  onClose,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(isAdminAuthenticated());
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState('');

  // Password change modal state
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');

  // Upload form state
  const [uploadMode, setUploadMode] = useState<'link' | 'file'>('link');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Cinematography');
  const [videoLink, setVideoLink] = useState('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [thumbnailMode, setThumbnailMode] = useState<'url' | 'file'>('url');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState<string>('');
  const [duration, setDuration] = useState('12:30');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Active tab: 'upload' | 'manage'
  const [activeTab, setActiveTab] = useState<'upload' | 'manage'>('upload');

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const thumbInputRef = useRef<HTMLInputElement | null>(null);

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const correctPassword = getAdminPassword();
    if (passwordInput === correctPassword) {
      setIsAuthenticated(true);
      setAdminAuthenticated(true);
      setPasswordError('');
    } else {
      setPasswordError('Invalid password. Default password is: ' + correctPassword);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setAdminAuthenticated(false);
    setPasswordInput('');
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 4) {
      setPasswordError('New password must be at least 4 characters long.');
      return;
    }
    setAdminPassword(newPassword);
    setPasswordSuccess('Password successfully updated!');
    setTimeout(() => {
      setIsChangingPassword(false);
      setPasswordSuccess('');
      setNewPassword('');
    }, 1800);
  };

  // Handle Video File selection & extract preview frame
  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFile(file);
    setSubmitError('');

    // Pre-fill title if empty from filename
    if (!title) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      setTitle(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
    }

    // Try extracting frame & duration
    const tempVideo = document.createElement('video');
    tempVideo.preload = 'metadata';
    tempVideo.src = URL.createObjectURL(file);
    tempVideo.onloadedmetadata = () => {
      const mins = Math.floor(tempVideo.duration / 60);
      const secs = Math.floor(tempVideo.duration % 60);
      setDuration(`${mins}:${secs < 10 ? '0' : ''}${secs}`);
      // Seek to 25% to grab thumbnail
      tempVideo.currentTime = Math.min(2, tempVideo.duration * 0.25);
    };
    tempVideo.onseeked = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 640;
        canvas.height = 360;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(tempVideo, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          if (!thumbnailPreview) {
            setThumbnailPreview(dataUrl);
            setThumbnailUrl(dataUrl);
          }
        }
      } catch {
        // Cross-origin / silent canvas fallback
      }
    };
  };

  // Handle Thumbnail file selection
  const handleThumbFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setThumbnailFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const res = ev.target?.result as string;
      setThumbnailPreview(res);
      setThumbnailUrl(res);
    };
    reader.readAsDataURL(file);
  };

  // Publish / Upload Form Submission
  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');

    if (!title.trim()) {
      setSubmitError('Please enter a video title.');
      return;
    }

    if (!description.trim()) {
      setSubmitError('Please enter a description for your audience.');
      return;
    }

    if (uploadMode === 'link' && !videoLink.trim()) {
      setSubmitError('Please enter a valid video link or YouTube URL.');
      return;
    }

    if (uploadMode === 'file' && !uploadedFile) {
      setSubmitError('Please select a video file from your computer.');
      return;
    }

    let finalThumbnail =
      thumbnailPreview ||
      thumbnailUrl;

    if (!finalThumbnail && uploadMode === 'link') {
      const ytRegex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i;
      const match = videoLink.match(ytRegex);
      if (match && match[1]) {
        finalThumbnail = `https://img.youtube.com/vi/${match[1]}/hqdefault.jpg`;
      }
    }

    if (!finalThumbnail) {
      finalThumbnail = 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&auto=format&fit=crop&q=80';
    }

    setIsSubmitting(true);
    const videoId = `vid-${Date.now()}`;

    try {
      let finalVideoUrl = '';
      let sourceType: 'url' | 'file' | 'youtube' = 'url';

      if (uploadMode === 'file' && uploadedFile) {
        // Save to IndexedDB
        await saveVideoBlob(videoId, uploadedFile);
        finalVideoUrl = `indexeddb:${videoId}`;
        sourceType = 'file';
      } else {
        const parsed = parseVideoSource(videoLink.trim());
        sourceType = parsed.type;
        finalVideoUrl = videoLink.trim();
      }

      const newVideo: Video = {
        id: videoId,
        title: title.trim(),
        description: description.trim(),
        thumbnailUrl: finalThumbnail,
        videoUrl: finalVideoUrl,
        sourceType,
        duration: duration || '10:00',
        views: 1,
        likes: 0,
        uploadedAt: 'Just now',
        category,
        tags: [category.toLowerCase(), 'creator', 'official'],
      };

      addVideo(newVideo);
      onVideoAdded(newVideo);

      setSubmitSuccess(true);
      setIsSubmitting(false);

      // Reset form
      setTimeout(() => {
        setTitle('');
        setDescription('');
        setVideoLink('');
        setUploadedFile(null);
        setThumbnailPreview('');
        setThumbnailUrl('');
        setThumbnailFile(null);
        setSubmitSuccess(false);
        setActiveTab('manage');
      }, 1500);
    } catch (err) {
      console.error(err);
      setSubmitError('Failed to upload video. Please try again.');
      setIsSubmitting(false);
    }
  };

  // 1. Password Login View
  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-12 px-4">
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-md">
          <div className="w-12 h-12 rounded-2xl bg-red-600/10 border border-red-500/20 text-red-500 flex items-center justify-center mx-auto mb-4">
            <Shield className="w-6 h-6" />
          </div>

          <h2 className="text-xl font-bold text-center text-zinc-100 tracking-tight">
            Owner / Creator Studio
          </h2>
          <p className="text-xs text-center text-zinc-400 mt-1 mb-6">
            Enter the owner password to access video uploads and content management.
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label
                htmlFor="admin-password-input"
                className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2"
              >
                Studio Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="admin-password-input"
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Enter creator password..."
                  autoFocus
                  className="w-full pl-10 pr-4 py-2.5 bg-zinc-950 border border-zinc-700/80 rounded-xl text-zinc-100 placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
            </div>

            {passwordError && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-950/50 border border-red-900/80 text-red-400 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{passwordError}</span>
              </div>
            )}

            <button
              id="admin-login-submit-btn"
              type="submit"
              className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl text-sm transition-all duration-200 shadow-lg shadow-red-600/20 cursor-pointer"
            >
              Unlock Creator Studio
            </button>
          </form>

          {/* Helper hint for convenient testing */}
          <div className="mt-6 pt-4 border-t border-zinc-800 text-center">
            <p className="text-xs text-zinc-400">
              Default password:{' '}
              <button
                type="button"
                onClick={() => setPasswordInput(DEFAULT_ADMIN_PASSWORD)}
                className="text-red-400 font-mono font-semibold underline hover:text-red-300 ml-1 cursor-pointer"
              >
                {DEFAULT_ADMIN_PASSWORD}
              </button>
            </p>
          </div>
        </div>
      </div>
    );
  }

  // 2. Authenticated Admin Dashboard
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6">
      {/* Studio Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-md shadow-red-600/30">
            <Film className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-zinc-100">
                Creator Studio Dashboard
              </h1>
              <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800/80">
                Authorized
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              Publish new videos, manage catalog, and adjust studio settings.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="admin-change-password-btn"
            onClick={() => setIsChangingPassword(!isChangingPassword)}
            className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Key className="w-3.5 h-3.5" />
            <span>Password</span>
          </button>

          <button
            id="admin-logout-btn"
            onClick={handleLogout}
            className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Lock Studio</span>
          </button>

          <button
            id="admin-exit-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800"
            title="Return to home"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Password Change Dialog */}
      {isChangingPassword && (
        <form
          onSubmit={handleChangePassword}
          className="my-4 p-4 rounded-xl bg-zinc-900 border border-zinc-700/80 max-w-md space-y-3"
        >
          <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-1.5">
            <Key className="w-4 h-4 text-red-500" />
            Change Owner Password
          </h3>
          <input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="Enter new studio password..."
            className="w-full px-3 py-2 bg-zinc-950 border border-zinc-700 rounded-lg text-xs text-zinc-100"
          />
          {passwordSuccess && (
            <p className="text-xs text-emerald-400">{passwordSuccess}</p>
          )}
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsChangingPassword(false)}
              className="px-3 py-1 text-xs text-zinc-400 hover:text-zinc-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-semibold"
            >
              Save Password
            </button>
          </div>
        </form>
      )}

      {/* Tabs: Upload Video vs Manage Videos */}
      <div className="flex items-center gap-2 mt-6 mb-6 border-b border-zinc-800 pb-2">
        <button
          id="admin-tab-upload"
          onClick={() => setActiveTab('upload')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
            activeTab === 'upload'
              ? 'bg-zinc-100 text-zinc-950 shadow-sm'
              : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
          }`}
        >
          <Upload className="w-4 h-4" />
          <span>Upload Video</span>
        </button>

        <button
          id="admin-tab-manage"
          onClick={() => setActiveTab('manage')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
            activeTab === 'manage'
              ? 'bg-zinc-100 text-zinc-950 shadow-sm'
              : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
          }`}
        >
          <FileVideo className="w-4 h-4" />
          <span>Manage Videos ({videos.length})</span>
        </button>
      </div>

      {/* TAB 1: UPLOAD VIDEO FORM */}
      {activeTab === 'upload' && (
        <form onSubmit={handlePublish} className="space-y-6">
          {submitSuccess && (
            <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-sm flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span>Video successfully uploaded and published to your channel!</span>
            </div>
          )}

          {submitError && (
            <div className="p-4 rounded-xl bg-red-950/80 border border-red-800 text-red-300 text-sm flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-400" />
              <span>{submitError}</span>
            </div>
          )}

          {/* 1. Video Source Selection: File or Link */}
          <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
              <FileVideo className="w-4 h-4 text-red-500" />
              1. Video Media Source (File or Link)
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                id="upload-mode-link-btn"
                onClick={() => setUploadMode('link')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs sm:text-sm font-semibold transition-all ${
                  uploadMode === 'link'
                    ? 'border-red-500 bg-red-950/20 text-red-400'
                    : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <LinkIcon className="w-4 h-4" />
                <span>Video Link (YouTube / MP4 URL)</span>
              </button>

              <button
                type="button"
                id="upload-mode-file-btn"
                onClick={() => setUploadMode('file')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs sm:text-sm font-semibold transition-all ${
                  uploadMode === 'file'
                    ? 'border-red-500 bg-red-950/20 text-red-400'
                    : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Upload className="w-4 h-4" />
                <span>Upload Local File (.mp4, .webm)</span>
              </button>
            </div>

            {uploadMode === 'link' ? (
              <div className="space-y-2">
                <label
                  htmlFor="video-link-input"
                  className="block text-xs font-medium text-zinc-400"
                >
                  Video URL or YouTube Link
                </label>
                <input
                  id="video-link-input"
                  type="text"
                  value={videoLink}
                  onChange={(e) => {
                    const val = e.target.value;
                    setVideoLink(val);
                    const ytRegex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i;
                    const match = val.match(ytRegex);
                    if (match && match[1] && !thumbnailPreview && !thumbnailUrl) {
                      const autoThumb = `https://img.youtube.com/vi/${match[1]}/hqdefault.jpg`;
                      setThumbnailPreview(autoThumb);
                      setThumbnailUrl(autoThumb);
                    }
                  }}
                  placeholder="https://www.youtube.com/watch?v=... or https://example.com/video.mp4"
                  className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-700/80 rounded-xl text-xs sm:text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-red-500"
                />
                <p className="text-[11px] text-zinc-500">
                  Supports YouTube embeds or direct MP4/WebM video streaming URLs.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="video/mp4,video/webm,video/ogg,video/quicktime"
                  onChange={handleVideoFileChange}
                  className="hidden"
                />
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-zinc-700 hover:border-red-500/80 rounded-xl p-6 text-center cursor-pointer bg-zinc-950/50 hover:bg-zinc-950 transition-colors"
                >
                  <Upload className="w-8 h-8 text-zinc-500 mx-auto mb-2" />
                  {uploadedFile ? (
                    <div>
                      <p className="text-sm font-semibold text-emerald-400">
                        Selected: {uploadedFile.name}
                      </p>
                      <p className="text-xs text-zinc-400 mt-1">
                        Size: {(uploadedFile.size / (1024 * 1024)).toFixed(2)} MB • Ready to upload
                      </p>
                    </div>
                  ) : (
                    <div>
                      <p className="text-sm font-medium text-zinc-300">
                        Click or drag video file here
                      </p>
                      <p className="text-xs text-zinc-500 mt-1">
                        MP4, WebM, MOV supported (Stored in browser storage)
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* 2. Title and Description */}
          <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
              <Film className="w-4 h-4 text-red-500" />
              2. Video Metadata (Title & Description)
            </h3>

            <div>
              <label
                htmlFor="video-title-input"
                className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5"
              >
                Video Title *
              </label>
              <input
                id="video-title-input"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., The Secret to Natural Cinematic Depth"
                required
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-700/80 rounded-xl text-zinc-100 placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="video-category-select"
                  className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5"
                >
                  Category
                </label>
                <select
                  id="video-category-select"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2.5 bg-zinc-950 border border-zinc-700/80 rounded-xl text-zinc-100 text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  <option value="Cinematography">Cinematography</option>
                  <option value="Studio Tour">Studio Tour</option>
                  <option value="Theory & Craft">Theory & Craft</option>
                  <option value="Color Grading">Color Grading</option>
                  <option value="Sound Design">Sound Design</option>
                  <option value="Behind The Scenes">Behind The Scenes</option>
                  <option value="Tech & Gear">Tech & Gear</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="video-duration-input"
                  className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5"
                >
                  Estimated Duration
                </label>
                <input
                  id="video-duration-input"
                  type="text"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  placeholder="e.g. 14:20"
                  className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-700/80 rounded-xl text-zinc-100 text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="video-description-input"
                className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5"
              >
                Description *
              </label>
              <textarea
                id="video-description-input"
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What is this video about? Include chapters, gear used, and context for viewers..."
                required
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-700/80 rounded-xl text-zinc-100 placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
          </div>

          {/* 3. Thumbnail Selection */}
          <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-red-500" />
              3. Thumbnail Image
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setThumbnailMode('url')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium ${
                      thumbnailMode === 'url'
                        ? 'bg-zinc-800 text-white'
                        : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    Image URL
                  </button>
                  <button
                    type="button"
                    onClick={() => setThumbnailMode('file')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium ${
                      thumbnailMode === 'file'
                        ? 'bg-zinc-800 text-white'
                        : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    Upload Image
                  </button>
                </div>

                {thumbnailMode === 'url' ? (
                  <input
                    id="thumbnail-url-input"
                    type="text"
                    value={thumbnailUrl}
                    onChange={(e) => {
                      setThumbnailUrl(e.target.value);
                      setThumbnailPreview(e.target.value);
                    }}
                    placeholder="https://images.unsplash.com/... or image link"
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-700/80 rounded-xl text-xs sm:text-sm text-zinc-100 placeholder-zinc-500"
                  />
                ) : (
                  <div>
                    <input
                      ref={thumbInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleThumbFileChange}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => thumbInputRef.current?.click()}
                      className="w-full py-3 bg-zinc-950 border border-zinc-700/80 hover:border-red-500 rounded-xl text-xs font-medium text-zinc-300"
                    >
                      {thumbnailFile ? thumbnailFile.name : 'Choose Image File...'}
                    </button>
                  </div>
                )}
              </div>

              {/* Thumbnail Preview box */}
              <div className="relative aspect-video rounded-xl bg-zinc-950 border border-zinc-800 overflow-hidden flex items-center justify-center">
                {thumbnailPreview ? (
                  <img
                    src={thumbnailPreview}
                    alt="Preview"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center p-4 text-zinc-600">
                    <ImageIcon className="w-8 h-8 mx-auto mb-1 opacity-50" />
                    <span className="text-xs">Thumbnail Preview (16:9)</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Submit Action */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl text-sm font-medium text-zinc-400 hover:text-white"
            >
              Cancel
            </button>

            <button
              id="admin-publish-video-btn"
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-sm font-semibold shadow-lg shadow-red-600/30 flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Upload className="w-4 h-4" />
              <span>{isSubmitting ? 'Uploading & Processing...' : 'Publish Video to Channel'}</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB 2: MANAGE VIDEOS */}
      {activeTab === 'manage' && (
        <div className="space-y-4">
          <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
              <span className="text-sm font-semibold text-zinc-200">
                All Published Videos ({videos.length})
              </span>
              <button
                onClick={() => setActiveTab('upload')}
                className="text-xs text-red-400 hover:text-red-300 font-semibold"
              >
                + Add New Video
              </button>
            </div>

            <div className="divide-y divide-zinc-800/60">
              {videos.map((vid) => (
                <div
                  key={vid.id}
                  className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-zinc-900/80 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={vid.thumbnailUrl}
                      alt={vid.title}
                      referrerPolicy="no-referrer"
                      className="w-24 aspect-video rounded-lg object-cover bg-zinc-950 shrink-0"
                    />
                    <div className="min-w-0">
                      <h4 className="text-sm font-semibold text-zinc-100 truncate max-w-md">
                        {vid.title}
                      </h4>
                      <div className="flex items-center gap-3 text-xs text-zinc-400 mt-1">
                        <span>{vid.category}</span>
                        <span>•</span>
                        <span>{formatCount(vid.views)} views</span>
                        <span>•</span>
                        <span>{formatCount(vid.likes)} likes</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      onClick={() => onViewVideo(vid)}
                      className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs flex items-center gap-1.5"
                      title="View Video Page"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>Watch</span>
                    </button>

                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete "${vid.title}"?`)) {
                          deleteVideo(vid.id);
                          onVideoDeleted(vid.id);
                        }
                      }}
                      className="p-2 rounded-lg bg-zinc-900 hover:bg-red-950/80 text-zinc-400 hover:text-red-400 text-xs border border-zinc-800"
                      title="Delete Video"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
