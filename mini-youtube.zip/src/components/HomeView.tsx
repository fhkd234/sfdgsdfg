import React, { useState } from 'react';
import { Video } from '../types';
import { ChannelHeader } from './ChannelHeader';
import { VideoCard } from './VideoCard';
import { Sparkles, Film, PlusCircle } from 'lucide-react';

interface HomeViewProps {
  videos: Video[];
  onSelectVideo: (video: Video) => void;
  onOpenUpload: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  videos,
  onSelectVideo,
  onOpenUpload,
}) => {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredVideos =
    activeCategory === 'All'
      ? videos
      : videos.filter((v) => v.category === activeCategory);

  return (
    <div className="w-full">
      {/* Creator Channel Header */}
      <ChannelHeader
        videos={videos}
        activeCategory={activeCategory}
        setActiveCategory={setActiveCategory}
      />

      {/* Main Video Grid Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
        {/* Section Title & Count */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Film className="w-5 h-5 text-red-500" />
            <h2 className="text-lg sm:text-xl font-bold text-zinc-100">
              {activeCategory === 'All' ? 'Latest Videos' : `${activeCategory} Videos`}
            </h2>
            <span className="text-xs text-zinc-400 font-medium px-2 py-0.5 rounded-full bg-zinc-900 border border-zinc-800">
              {filteredVideos.length}
            </span>
          </div>

          <button
            onClick={onOpenUpload}
            className="hidden sm:flex items-center gap-1.5 text-xs text-zinc-400 hover:text-red-400 transition-colors font-medium cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Upload New Video</span>
          </button>
        </div>

        {/* Video Grid: 1 col mobile, 2 col tablet, 3 col desktop */}
        {filteredVideos.length > 0 ? (
          <div
            id="home-video-grid"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-5 gap-y-8"
          >
            {filteredVideos.map((video) => (
              <VideoCard
                key={video.id}
                video={video}
                onSelect={onSelectVideo}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 px-4 bg-zinc-900/30 border border-zinc-800 rounded-2xl max-w-md mx-auto">
            <p className="text-sm text-zinc-300 font-medium">
              No videos in the &quot;{activeCategory}&quot; category yet.
            </p>
            <button
              onClick={() => setActiveCategory('All')}
              className="mt-3 text-xs text-red-400 hover:text-red-300 font-semibold"
            >
              View all videos
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
